import * as React from 'react';
import Header from '../components/Header';
import Footer from '../components/Footer';
import { BrowserRouter as Router, NavLink, Route } from 'react-router-dom';
import Dashboard from './DashboardContainer';
import { PrivateRoute } from '../components/PrivateRoute/PrivateRoute';
import LoginContainer from './LoginContainer';
import LogOutContainer from './LogOutContainer';

const ProjectBatch = () => <h2>Project Batch</h2>;
const AssociateDetail = () => <h2>Associate Detail</h2>;
const KtDetail = () => <h2>Kt Detail</h2>;
interface IAppState {
    isAuthenticated: boolean;
}
export class App extends React.Component<{}, IAppState> {
    public constructor(props: any) {
        super(props);
        this.state = {
            isAuthenticated: false
        };
    }

    public componentDidMount() {
        this.setState({ isAuthenticated: sessionStorage.getItem('AssociateId') ? true : false });
    }

    private onAuthenticated = () => {
        this.setState({ isAuthenticated: true });
    }

    private onLogOut = () => {
        this.setState({ isAuthenticated: false });
    }

    public render() {
        return (
            <div>
                <Header />
                <Router>
                    <div>
                        <nav className="navbar navbar-default">
                            <div className="container-fluid">
                                <ul className="nav navbar-nav">
                                    <li>
                                        <NavLink activeClassName="active" exact={true} to="/">Dashboard</NavLink>
                                    </li>
                                    <li>
                                        <NavLink activeClassName="active" to="/project-batch">Project Batch</NavLink>
                                    </li>
                                    <li>
                                        <NavLink activeClassName="active" to="/associate-detail">Associate Detail</NavLink>
                                    </li>
                                    <li>
                                        <NavLink activeClassName="active" to="/kt-detail">Kt Detail</NavLink>
                                    </li>
                                    {!this.state.isAuthenticated &&
                                        <li>
                                            <NavLink activeClassName="active" to="/login">Login</NavLink>
                                        </li>}
                                    {this.state.isAuthenticated &&
                                        <li>
                                            <NavLink activeClassName="active" to="/logout">Logout</NavLink>
                                        </li>}
                                </ul>
                            </div>
                        </nav>
                        <PrivateRoute path="/" exact={true} component={Dashboard} />
                        <Route path="/login" component={() => <LoginContainer onAuthenticated={() => this.onAuthenticated()} />} />
                        <Route path="/logout" component={() => <LogOutContainer onLogOut={() => this.onLogOut()} />} />
                        <PrivateRoute path="/project-batch" component={ProjectBatch} />
                        <PrivateRoute path="/associate-detail" component={AssociateDetail} />
                        <PrivateRoute path="/kt-detail" component={KtDetail} />
                    </div>
                </Router>
                <Footer />
            </div>);
    }
}
