import * as React from 'react';

const Footer = () => {
  return <div className="footer">© Copyright FNZ UK Ltd 2018.</div>;
};

export default Footer;