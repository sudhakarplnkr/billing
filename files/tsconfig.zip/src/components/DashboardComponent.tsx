import * as React from 'react';
import { Doughnut } from 'react-chartjs-2';
import { Dashboard } from '../ApiClient';

export default class DashboardComponent extends React.Component<{ dashboard: Dashboard[] }, {}> {
    public render() {
        return (
            <div>
                {this.props.dashboard.map((dashboard: Dashboard) => {
                    const option = {
                        labels: [dashboard.projectName ? dashboard.projectName : ''],
                        datasets: [
                            {
                                data: [1, dashboard.completedCount],
                                backgroundColor: ['#000'],
                                hoverBackgroundColor: ['#000']
                            }
                        ]
                    };
                    return <div key={dashboard.projectId} className="col-sm-3">
                        <Doughnut data={option} />
                    </div>;
                })}
            </div>
        );
    }
}
