import { DashboardClient, Dashboard } from '../ApiClient';
import { Request } from '../utils/HeaderExtension';

export default class DashbordService {
    private readonly dashboardClient: DashboardClient;
    public constructor() {
        this.dashboardClient = new DashboardClient(Request.baseUrl, Request.http);
    }

    public get(): Promise<Dashboard[] | null> {
        return this.dashboardClient.get();
    }
}