export const BASE_URL = 'http://localhost:52505';

declare global {
    interface Window { __REDUX_DEVTOOLS_EXTENSION__: any; }
}