import * as React from 'react';

const Header = () => {  
  return (<img src={'../../logo.png'} title="FNZ logo" />);
};

export default Header;