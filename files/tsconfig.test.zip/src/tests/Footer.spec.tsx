import { shallow } from 'enzyme';
import Footer from '../components/Footer';
import * as React from 'react';

it('Footer renders without crashing', () => {
    const wrapper =
        shallow(
            <Footer />
        );
    expect(wrapper).toMatchSnapshot();
});
