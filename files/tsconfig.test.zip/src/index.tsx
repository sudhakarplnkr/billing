import * as React from 'react';
import { render } from 'react-dom';
import 'bootstrap/dist/css/bootstrap.min.css';
import './style.css';
import App from './containers/App';
import { Provider } from 'react-redux';
import store, { history } from './store';
import { ConnectedRouter } from 'connected-react-router';
import 'react-fa';
import ReduxToastr from 'react-redux-toastr';

const target = document.querySelector('#root');

render(
  <Provider store={store}>
    <React.Fragment>
      <ReduxToastr timeOut={4000} newestOnTop={false} preventDuplicates={false} position="top-right" transitionIn="fadeIn" transitionOut="fadeOut" progressBar={true} closeOnToastrClick={true} />
      <ConnectedRouter history={history}>
        <App />
      </ConnectedRouter>
    </React.Fragment>
  </Provider>,
  target
);
