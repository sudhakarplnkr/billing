import { Project, ProjectGroup, ProjectGroupPlanWithStatus, Associate, KnowledgeTransfer, Mode, Role, AssociateProjectGroup } from '../typings/ApiClient';
import { ProjectGroupPlan } from '../typings/ApiClient';

export interface IProjectProps {
    loadProjects(): void;
    loadBatches(projectId: string): void;
    loadProjectGroupPlan(batchId: string): void;
    showModal(show: Boolean): void;
    loadAddPlan(addPlan: Boolean): void;
    loadAddBatch(addBatch: Boolean, projectId: string, projectGroupId: string): void;
    projectGroupPlan: ProjectGroupPlanWithStatus[];
    project: Project[];
    batch: ProjectGroup[];
    showDialog: Boolean;
    showAddPlan: Boolean;
    showAddBatch: Boolean;
    selectedProjectId: string;
    selectedBatchId: string;
    associate: Associate[];
    knowledgeTransfer: KnowledgeTransfer[];
    mode: Mode[];
    role: Role[];
    associateProjectGroup: AssociateProjectGroup[];
}
export interface IProjectState {
    project: Project[];
    batch: ProjectGroup[];
    projectGroupPlan: ProjectGroupPlan[];
    message: string;
    showDialog: Boolean;
    showAddPlan: Boolean;
    showAddBatch: Boolean;
    associate: Associate[];
    selectedProjectId: string;
    selectedBatchId: string;
    knowledgeTransfer: KnowledgeTransfer[];
    mode: Mode[];
    role: Role[];
    associateProjectGroup: AssociateProjectGroup[];
}