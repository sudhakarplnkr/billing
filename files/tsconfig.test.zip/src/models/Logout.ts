export interface ILogoutProps {
    onLogout(): void;
}