export interface IModalDialogProps {    
    showModal(show: Boolean): void;    
}
