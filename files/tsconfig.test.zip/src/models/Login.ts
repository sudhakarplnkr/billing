export interface ILoginProps {
    associateId?: number;
    onLogin(): void;
    onChange(event: React.ChangeEvent<HTMLInputElement>): void;
}

export interface ILoginState {
    associateId?: number;
    isAuthenticated: boolean;
}

export interface ILoginContainerProps {
    associateId?: number;
    onLogin(associateId?: number): void;
    onAuthenticated(): void;
    onAssociateIdChange(associateId?: number): void;
    isAuthenticated: boolean;
}
