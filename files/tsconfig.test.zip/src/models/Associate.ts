﻿import { AssociateDetails, Project, AccountRole, Team } from '../typings/ApiClient';
import { Role } from '../typings/ApiClient';

export interface IAssociateProps {
    loadAssociate(): void;
    loadAddAssociate(isAddEdit: boolean): void;
    Associate: AssociateDetails[];
    employeeDetail: EmployeeDetail;
    isAddEdit: boolean;
    Role: Role[];
    Project: Project[];
    accountRole: AccountRole[];
    loadTeam(projectId: string): void;
    team: Team[];
    loadCalendarJoin(isCalJoin: boolean): void;
    frmField: { CognizantId: '', AssociateName: '' };
    addAssociateDetail: (associateDetails: AssociateDetails) => void;
    updateAssociateDetail: (employeeDetail: EmployeeDetail) => void;
}

export interface IAssociateState {
    Associate: AssociateDetails[];
    Role: Role[];
    Project: Project[];
    isAddEdit: boolean;
    accountRole: AccountRole[];
    team: Team[];
    frmField: { CognizantId: '', AssociateName: '' };
    message: string;
}

export interface EmployeeDetail {
    associateId?: string;
    designationId?: string | undefined;
    cognizantId?: string | undefined;
    associateName?: string | undefined;
    rLGUserName?: string | undefined;
    rLGStaffId?: string | undefined;
    rLGRoleId?: string | undefined;
    rLGEmail?: string | undefined;
    assetNo?: string | undefined;
    virtualMachineNo?: string | undefined;
    portfolio?: string | undefined;
    rLGDateofJoining?: Date | undefined;
    rLGDateofLeaving?: Date | undefined;
    rLGExperience?: number | undefined;
    billable?: string | undefined;
    location?: string | undefined;
    contactNo?: string | undefined;
    projectId?: string;
    teamId?: string | undefined;
    cognizantRoleId?: string;
    cognizantEmailId?: string | undefined;
    projectName?: string | undefined;
}