export interface IAppProps {
    isAuthenticated: boolean;
    onAuthenticated(): void;
    onLogout(): void;
}

export interface IAppState {
    isAuthenticated: boolean;
}

export interface Link {
    name: string;
    to: string;
}
