import { GET_ASSOCIATEPLAN, UPLOAD_ASSOCIATEPLAN, UPDATE_ASSOCIATEPLAN } from '../actions/KtDetailsActions';
import { IKtDetailsState, FileAssociatePlan } from '../models/KtDetails';

const initialState: IKtDetailsState = {
    AssociatePlans: []
};

const KtDetailsReducer = (state = initialState, action: any) => {
    switch (action.type) {
        case GET_ASSOCIATEPLAN:
            return {
                ...state,
                AssociatePlans: action.payload
            };
        case UPLOAD_ASSOCIATEPLAN:
            let associatePalns = [...state.AssociatePlans];
            updateAssociatePlan(associatePalns, action.payload);
            return {
                ...state,
                AssociatePlans: associatePalns
            };
        case UPDATE_ASSOCIATEPLAN:
            return {
                ...state,
                AssociatePlans: action.payload
            };
        default:
            return state;
    }
};

const updateAssociatePlan = (associatePlans: FileAssociatePlan[], associatePlan: FileAssociatePlan) => {
    const updatedPlan = associatePlans.filter((associate: FileAssociatePlan) => associate.id === associatePlan.associateId).pop();
    if (updatedPlan) {
        updatedPlan.proof = associatePlan.fileData;
    }
};

export default KtDetailsReducer;
