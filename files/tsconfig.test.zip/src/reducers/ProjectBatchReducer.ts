import { LOAD_PROJECT, PROJECT_FAILED_RESPONSE, LOAD_BATCH, BATCH_FAILED_RESPONSE, LOAD_PROJECTGROUPPLAN, PROJECTGROUPPLAN_FAILED_RESPONSE, SHOW_MODAL, LOAD_ASSOCIATE_ADD_PLAN, ASSOCIATE_ADD_PLAN_FAILED_RESPONSE, LOAD_KNOWLEDGE_TRANSFER, KNOWLEDGE_TRANSFER_FAILED_RESPONSE, LOAD_MODE, MODE_FAILED_RESPONSE, LOAD_ROLE_ADD_PLAN, ROLE_ADD_PLAN_FAILED_RESPONSE, LOAD_ADD_PLAN, LOAD_ADD_BATCH, LOAD_ASSOCIATE_ADD_BATCH, ASSOCIATE_ADD_BATCH_FAILED_RESPONSE } from '../actions/ProjectBatchActions';
import { IProjectState } from '../models/ProjectBatch';

const initialState: IProjectState = {
    project: [],
    batch: [],
    projectGroupPlan: [],
    associate: [],
    knowledgeTransfer: [],
    mode: [],
    role: [],
    associateProjectGroup: [],
    showDialog: false,
    showAddPlan: false,
    showAddBatch: false,
    selectedProjectId: '',
    selectedBatchId: '',
    message: ''
};

const ProjectBatchReducer = (state = initialState, action: any) => {
    switch (action.type) {
        case LOAD_PROJECT:
            return {
                ...state,
                project: action.payload
            };
        case PROJECT_FAILED_RESPONSE:
            return {
                ...state,
                project: action.payload
            };
        case LOAD_BATCH:
            return {
                ...state,
                batch: action.payload.batch,
                selectedProjectId: action.payload.projectId
            };
        case BATCH_FAILED_RESPONSE:
            return {
                ...state,
                batch: action.payload.batch,
                selectedProjectId: action.payload.projectId
            };
        case LOAD_PROJECTGROUPPLAN:
            return {
                ...state,
                projectGroupPlan: action.payload.team,
                selectedBatchId: action.payload.batchId
            };
        case PROJECTGROUPPLAN_FAILED_RESPONSE:
            return {
                ...state,
                projectGroupPlan: action.payload.team,
                selectedBatchId: action.payload.batchId
            };
        case SHOW_MODAL:
            return {
                ...state,
                showDialog: action.payload
            };
        case LOAD_ADD_PLAN:
            return {
                ...state,
                showAddPlan: action.payload
            };
        case LOAD_ASSOCIATE_ADD_PLAN:
            return {
                ...state,
                associate: action.payload
            };
        case ASSOCIATE_ADD_PLAN_FAILED_RESPONSE:
            return {
                ...state,
                associate: action.payload
            };
        case LOAD_KNOWLEDGE_TRANSFER:
            return {
                ...state,
                knowledgeTransfer: action.payload
            };
        case KNOWLEDGE_TRANSFER_FAILED_RESPONSE:
            return {
                ...state,
                knowledgeTransfer: action.payload
            };
        case LOAD_MODE:
            return {
                ...state,
                mode: action.payload
            };
        case MODE_FAILED_RESPONSE:
            return {
                ...state,
                mode: action.payload
            };
        case LOAD_ROLE_ADD_PLAN:
            return {
                ...state,
                role: action.payload
            };
        case ROLE_ADD_PLAN_FAILED_RESPONSE:
            return {
                ...state,
                role: action.payload
            };
        case LOAD_ADD_BATCH:
            return {
                ...state,
                showAddBatch: action.payload
            };
        case LOAD_ASSOCIATE_ADD_BATCH:
            return {
                ...state,
                associateProjectGroup: action.payload
            };
        case ASSOCIATE_ADD_BATCH_FAILED_RESPONSE:
            return {
                ...state,
                associateProjectGroup: action.payload
            };
        default:
            return state;
    }
};

export default ProjectBatchReducer;