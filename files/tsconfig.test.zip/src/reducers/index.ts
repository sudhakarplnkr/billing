import { combineReducers } from 'redux';
import dashboard from './DashboardReducer';
import LoginReducer from './LoginReducer';
import AppReducer from './AppReducer';
import KtDetailsReducer from './KtDetailsReducer';
import AssociateReducer from './AssociateReducer';
import ProjectBatchReducer from './ProjectBatchReducer';
import {reducer as toastrReducer} from 'react-redux-toastr';

export default combineReducers({
  app: AppReducer,
  data: dashboard,
  login: LoginReducer,
  ktDetails: KtDetailsReducer,
  associate: AssociateReducer,
  projectData: ProjectBatchReducer,
  batchData: ProjectBatchReducer,
  projectGroupData: ProjectBatchReducer,
  isAddEditValue: AssociateReducer,
  showDialogValue: ProjectBatchReducer,
  showAddPlanValue: ProjectBatchReducer,
  showAddBatchValue: ProjectBatchReducer,
  associateData: ProjectBatchReducer,
  ktData: ProjectBatchReducer,
  modeData: ProjectBatchReducer,
  roleData: ProjectBatchReducer,
  associateProjectGroupData: ProjectBatchReducer,
  selectedProjectIdValue: ProjectBatchReducer,
  selectedBatchIdValue: ProjectBatchReducer,
  roleAddData: AssociateReducer,
  projectAddData: AssociateReducer,
  accountRoleData: AssociateReducer,
  teamData: AssociateReducer,
  associateDetailsData: AssociateReducer,
  toastr: toastrReducer
  });
