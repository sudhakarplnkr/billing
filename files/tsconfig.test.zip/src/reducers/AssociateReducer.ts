﻿import { LOAD_ASSOCIATE, ADD_ASSOCIATE, ADD_DATA_ASSOCIATE, ADD_DATA_ASSOCIATE_FAILED_RESPONSE, LOAD_PROJECT, LOAD_TEAM, LOAD_TEAM_FAILED_RESPONSE, LOAD_PROJECT_FAILED_RESPONSE, LOAD_ACCOUNT_ROLE, LOAD_ACCOUNT_ROLE_FAILED_RESPONSE, LOAD_ROLE, LOAD_ROLE_FAILED_RESPONSE, ASSOCIATE_FAILED_RESPONSE, Action, UPDATE_ASSOCIATE_DETAILS } from '../actions/AssociateActions';
import { IAssociateState } from '../models/Associate';

const initialState: IAssociateState = {
    Associate: [],
    Role: [],
    Project: [],
    isAddEdit: false,
    accountRole: [],
    team: [],
    frmField: {CognizantId: '', AssociateName: ''},
    message: ''
};

const AssociateReducer = (state = initialState, action: Action) => {
    switch (action.type) {
        case LOAD_ASSOCIATE:
            return {
                ...state,
                Associate: action.payload
            };
            case ADD_ASSOCIATE:
            return {
                ...state,
                isAddEdit: action.payload
            };
        case ASSOCIATE_FAILED_RESPONSE:
            return {
                ...state,
                associate: action.payload
            };
            case LOAD_ROLE:
            return {
                ...state,
                Role: action.payload
            };
            case LOAD_ROLE_FAILED_RESPONSE:
            return {
                ...state,
                Role: action.payload
            };
            case LOAD_PROJECT:
            return {
                ...state,
                Project: action.payload
            };
            case LOAD_PROJECT_FAILED_RESPONSE:
            return {
                ...state,
                Project: action.payload
            };
            case LOAD_ACCOUNT_ROLE:
            return {
                ...state,
                accountRole: action.payload
            };
            case LOAD_ACCOUNT_ROLE_FAILED_RESPONSE:
            return {
                ...state,
                accountRole: action.payload
            };
            case LOAD_TEAM:
            return {
                ...state,
                team: action.payload
            };
            case LOAD_TEAM_FAILED_RESPONSE:
            return {
                ...state,
                team: action.payload
            };
            case ADD_DATA_ASSOCIATE:
            return {
                ...state,
                team: action.payload
            };
            case ADD_DATA_ASSOCIATE_FAILED_RESPONSE:
            return {
                ...state,
                team: action.payload
            };
            case UPDATE_ASSOCIATE_DETAILS:
            return {
                ...state,
                associateDetails: action.payload
            };
        default:
            return state;
    }
};

export default AssociateReducer;
