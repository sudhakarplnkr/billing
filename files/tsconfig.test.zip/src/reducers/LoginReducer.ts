import { ON_LOGIN, CHANGE_ASSOCIATE_ID } from '../actions/LoginActions';
import { ILoginState } from '../models/Login';

const initialState: ILoginState = {
    associateId: undefined,
    isAuthenticated: false
};

const LoginReducer = (state = initialState, action: any) => {
    switch (action.type) {
        case ON_LOGIN:
            return {
                ...state,
                associateId: action.payload.associateId,
                isAdmin: action.payload.isAdmin,
                isAuthenticated: true
            };       
        case CHANGE_ASSOCIATE_ID:
            return {
                ...state,
                associateId: action.payload
            };
        default:
            return state;
    }
};

export default LoginReducer;
