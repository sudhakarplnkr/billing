import * as React from 'react';
import { Redirect } from 'react-router';
import SessionManagement from '../utils/SessionManagement';
import { ILogoutProps } from '../models/Logout';

class LogoutContainer extends React.Component<ILogoutProps, {}> {
    public constructor(props: ILogoutProps) {
        super(props);
        this.handleOnLogout();
    }

    private handleOnLogout = (): void => {
        SessionManagement.RemoveToken();
        this.props.onLogout();
    };

    public render() {
        return (<Redirect to="/login" />);
    }
}

export default LogoutContainer;