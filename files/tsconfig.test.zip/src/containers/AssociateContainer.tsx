﻿import * as React from 'react';
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';

import { loadAssociate, loadAddAssociate, loadTeam, addAssociateDetail, updateAssociateDetail } from '../actions/AssociateActions';
import AssociateComponent from '../components/AssociateComponent';
import { IAssociateState, IAssociateProps, EmployeeDetail } from '../models/Associate';
import { AssociateDetails } from '../typings/ApiClient';

class AssociateContainer extends React.Component<IAssociateProps, IAssociateState> {
    public componentWillMount() {
        this.props.loadAssociate();
    }

    private addAssociateDetail() {
        const associateDetail = { ...this.props.employeeDetail } as AssociateDetails;
        this.props.addAssociateDetail(associateDetail);
    }

    private updateAssociateDetail(employeeDetail: EmployeeDetail) {
        const associateDetail = { ...this.props.employeeDetail, ...employeeDetail };
        this.props.updateAssociateDetail(associateDetail);
    }

    public render() {
        return (
            <AssociateComponent updateAssociateDetail={(employeeDetail: EmployeeDetail) => this.updateAssociateDetail(employeeDetail)} associate={this.props.Associate} loadAddAssociate={(isAddEdit: boolean) => this.props.loadAddAssociate(isAddEdit)} isAddEdit={this.props.isAddEdit} role={this.props.Role} project={this.props.Project} accountRole={this.props.accountRole} team={this.props.team} loadTeam={(projectId: string) => this.props.loadTeam(projectId)} frmField={this.props.frmField} formHandler={() => this.addAssociateDetail()} />
        );
    }
}
const mapStateToProps = (state: any) => {
    return {
        Associate: state.associate.Associate,
        isAddEdit: state.isAddEditValue.isAddEdit,
        Role: state.roleAddData.Role,
        Project: state.projectAddData.Project,
        accountRole: state.accountRoleData.accountRole,
        team: state.teamData.team,
        associateDetails: state.associateDetailsData.associateDetails,
        employeeDetail: state.associate.associateDetails
    };
};

const mapDispatchToProps = (dispatch: any) =>
    bindActionCreators(
        {
            loadAssociate,
            loadAddAssociate,
            loadTeam,
            addAssociateDetail,
            updateAssociateDetail
        },
        dispatch
    );

export default connect(
    mapStateToProps,
    mapDispatchToProps
)(AssociateContainer);