import * as React from 'react';
import KtDetailsComponent from '../components/KtDetailsComponent';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import { IKtDetailsProps } from '../models/KtDetails';
import { getAssociatePlans, uploadPlan, onFileChange } from '../actions/KtDetailsActions';
import { FileParameter } from '../typings/FileManagementService';
import * as DownloadClient from '../utils/DownloadService';

class KtDetailsContainer extends React.Component<IKtDetailsProps, {}> {

    public componentDidMount() {
        if (this.props.getAssociatePlans) {
            this.props.getAssociatePlans();
        }
    }

    private onUploadPlan(associatePlanId: string, file: FileList) {
        if (this.props.AssociatePlans && this.props.onFileChange) {
            this.props.onFileChange(this.props.AssociatePlans, associatePlanId, file[0]);
        }
    }

    private downloadPlan = (file: string, fileName: string) => {
        DownloadClient.default.downloadFile(file, fileName);
    };

    public render() {
        return (
            <KtDetailsComponent
                AssociatePlans={this.props.AssociatePlans}
                onChange={(associatePlanId: string, file: FileList) => this.onUploadPlan(associatePlanId, file)}
                uploadPlan={(associatePlanId: string, fileParameter: FileParameter) => this.props.uploadPlan(associatePlanId, fileParameter)}
                downloadPlan={(file: string, fileName: string) => this.downloadPlan(file, fileName)}
            />
        );
    }
}

const mapStateToProps = (state: any) => {
    return {
        AssociatePlans: state.ktDetails.AssociatePlans
    };
};

const mapDispatchToProps = (dispatch: any) =>
    bindActionCreators(
        {
            getAssociatePlans,
            uploadPlan,
            onFileChange
        },
        dispatch
    );

export default connect(mapStateToProps, mapDispatchToProps)(KtDetailsContainer);
