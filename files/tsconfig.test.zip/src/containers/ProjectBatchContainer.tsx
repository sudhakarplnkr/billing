import * as React from 'react';
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import { loadProjects, loadBatches, loadProjectGroupPlan, showModal, loadAddPlan, loadAddBatch } from '../actions/ProjectBatchActions';
import ProjectBatchComponent from '../components/ProjectBatchComponent';
import { IProjectState, IProjectProps } from '../models/ProjectBatch';

class ProjectBatchContainer extends React.Component<IProjectProps, IProjectState> {

    public componentWillMount() {
        this.props.loadProjects();
    }
   
    public render() {
        return (
            <ProjectBatchComponent loadBatches={(projectId: string) => this.props.loadBatches(projectId)} loadProjectGroupPlan={(batchId: string) => this.props.loadProjectGroupPlan(batchId)}  project={this.props.project}batch={this.props.batch} projectGroupPlan={this.props.projectGroupPlan} showModal={(show: Boolean) => this.props.showModal(show)} loadAddPlan={(addPlan: Boolean) => this.props.loadAddPlan(addPlan)} showDialog={this.props.showDialog} showAddPlan={this.props.showAddPlan} associate={this.props.associate} mode={this.props.mode} role={this.props.role} knowledgeTransfer={this.props.knowledgeTransfer} loadAddBatch={(addBatch: Boolean, projectId: string, projectGroupId: string) => this.props.loadAddBatch(addBatch, projectId, projectGroupId)} showAddBatch={this.props.showAddBatch} selectedProjectId={this.props.selectedProjectId} selectedBatchId={this.props.selectedBatchId} associateProjectGroup={this.props.associateProjectGroup}/>
        );
    }
}
const mapStateToProps = (state: any) => {
    return {
        project: state.projectData.project,
        batch: state.batchData.batch,
        projectGroupPlan : state.projectGroupData.projectGroupPlan,
        showDialog: state.showDialogValue.showDialog,
        showAddPlan: state.showAddPlanValue.showAddPlan,
        showAddBatch: state.showAddBatchValue.showAddBatch,
        role: state.roleData.role,
        associate: state.associateData.associate,
        knowledgeTransfer: state.ktData.knowledgeTransfer,
        mode: state.modeData.mode,
        associateProjectGroup: state.associateProjectGroupData.associateProjectGroup,
        selectedProjectId: state.selectedProjectIdValue.selectedProjectId,
        selectedBatchId: state.selectedBatchIdValue.selectedBatchId
    };
};

const mapDispatchToProps = (dispatch: any) =>
    bindActionCreators(
        {
            loadProjects,
            loadBatches,
            loadProjectGroupPlan,
            showModal,
            loadAddPlan,
            loadAddBatch
        },
        dispatch
    );

export default connect(
    mapStateToProps,
    mapDispatchToProps
)(ProjectBatchContainer);