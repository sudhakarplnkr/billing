import * as React from 'react';
import Header from '../components/Header';
import Footer from '../components/Footer';
import { BrowserRouter as Router, Route } from 'react-router-dom';
import Dashboard from './DashboardContainer';
import { PrivateRoute } from '../components/PrivateRoute/PrivateRoute';
import LoginContainer from './LoginContainer';
import LogoutContainer from './LogoutContainer';
import ProjectBatchContainer from './ProjectBatchContainer';
import LinksComponent from '../components/LinkComponent';
import { IAppProps, Link, IAppState } from '../models/App';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import { onAuthenticated, onLogout } from '../actions/AppActions';
import SessionManagement from '../utils/SessionManagement';
import KtDetailsContainer from './KtDetailsContainer';
import AssociateContainer from './AssociateContainer';

class AppComponent extends React.Component<IAppProps, {}> {
    public render() {
        const menuLinks: Link[] = [
            { name: 'Dashboard', to: '/' },
            { name: 'Project Batch', to: '/project-batch' },
            { name: 'Associate Details', to: '/associate-detail' },
            { name: 'KT Details', to: '/kt-detail' },
            { name: 'Logout', to: '/logout' }
        ];

        return (
            <React.Fragment>
                <Header />
                <Router>
                    <React.Fragment>
                        <LinksComponent links={menuLinks} isAuthenticated={this.props.isAuthenticated} />
                        <PrivateRoute path="/" exact={true} component={Dashboard} />
                        <Route path="/login" component={() => <LoginContainer onAuthenticated={() => this.props.onAuthenticated()} />} />
                        <Route path="/logout" component={() => <LogoutContainer onLogout={() => this.props.onLogout()} />} />
                        <PrivateRoute path="/project-batch" component={ProjectBatchContainer} />
                        <PrivateRoute path="/associate-detail" component={AssociateContainer} />
                        <PrivateRoute path="/kt-detail" component={KtDetailsContainer} />
                    </React.Fragment>
                </Router>
                <Footer />
            </React.Fragment>);
    }
}

const mapStateToProps = ({ app: state }: { app: IAppState }) => {
    return {
        isAuthenticated: SessionManagement.GetToken() ? true : state.isAuthenticated
    };
};

const mapDispatchToProps = (dispatch: any) =>
    bindActionCreators(
        {
            onAuthenticated,
            onLogout
        },
        dispatch
    );

export default connect(mapStateToProps, mapDispatchToProps)(AppComponent);