﻿import * as React from 'react';
import 'react-fa';
import { AssociateDetails, Role, Project, AccountRole, Team } from '../typings/ApiClient';
import AssociateAddComponent from './AssociateAddComponent';
import { EmployeeDetail } from '../models/Associate';

type Props = {
    associate: AssociateDetails[];
    loadAddAssociate: (isAddEdit: boolean) => void;
    isAddEdit: boolean;
    role: Role[];
    project: Project[];
    accountRole: AccountRole[];
    loadTeam: (projectId: string) => void;
    team: Team[];
    frmField: { CognizantId: '', AssociateName: '' };
    formHandler: () => void;
    updateAssociateDetail: (employeeDetail: EmployeeDetail) => void;
};

const AssociateComponent = (props: Props) => {

    return (
        <div className="container-fluid">
            {props.isAddEdit ? <AssociateAddComponent updateAssociateDetail={(employeeDetail: EmployeeDetail) => props.updateAssociateDetail(employeeDetail)} role={props.role} project={props.project} accountRole={props.accountRole} team={props.team} loadTeam={(projectId: string) => props.loadTeam(projectId)} loadAddAssociate={(isAddEdit: boolean) => props.loadAddAssociate(isAddEdit)} frmField={props.frmField} formHandler={() => props.formHandler()} /> : ''}
            <div className="col-md-12">
                <button type="button" className="btn btn-link btn pull-right" onClick={() => props.loadAddAssociate(true)}>Add Associate</button>
            </div>
            {!props.isAddEdit ? <div>
                <table id="dtBasicExample" className="table table-striped table-bordered table-sm" cellSpacing="0">
                    <thead>
                        <tr>
                            <th className="th-sm">Associate ID
                    </th>
                            <th className="th-sm">Associate Name
                    </th>
                            <th className="th-sm">EmailId
                    </th>
                            <th className="th-sm">Billable
                    </th>
                            <th className="th-sm">Project Name
                    </th>
                            <th className="th-sm">Contact No
                    </th>
                            <th className="th-sm" />
                        </tr>
                    </thead>
                    <tbody>
                        {props.associate && props.associate.map((associate: AssociateDetails, index: number) => {
                            return (
                                <tr key={index}>
                                    <td>{associate.cognizantId}</td>
                                    <td>{associate.associateName}</td>
                                    <td>{associate.cognizantEmailId}</td>
                                    <td>{(() => {
                                        switch (associate.billable) {
                                            case null: return 'No';
                                            case '1': return 'No';
                                            default: return 'Yes';
                                        }
                                    })()
                                    }</td>
                                    <td>{associate.projectName}</td>
                                    <td>{associate.contactNo}</td>
                                    <td><i className="fa fa-edit" /><i className="fa fa-remove" /></td>
                                </tr>);
                        })}
                    </tbody>
                </table>
            </div> : ''}
        </div>
    );
};

export default AssociateComponent;