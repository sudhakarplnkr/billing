import * as React from 'react';
import 'react-fa';
import { AssociateProjectGroup } from '../typings/ApiClient';

type Props = {
    loadAddBatch: (addBatch: Boolean, projectId: string, projectGroupId: string) => void; 
    associateProjectGroup: AssociateProjectGroup[];
};
const AddBatchComponent = (props: Props) => {
  return (
    <div className="col-md-12" role="dialog" >
      <div className="modal-dialog">
        <div className="modal-content">
    <form className="form-horizontal">
    <div className="modal-header">
        <div>
            <h1>Add Batch</h1>
        </div>
        </div>
        <div className="modal-body" >
        <div className="md-dialog-container">
            <div className="form-group">
                <label className="control-label col-sm-3">Batch Name:</label>
                <div className="col-md-2">
                <input type="text" className="form-control" placeholder="Name" />
                 </div>
                <label className="control-label col-sm-3">Start Date:</label>
                <div className="col-md-4">
                <input type="date" className="form-control" placeholder="dd-MM-yyyy" />
                </div>
                </div>
            <div className="row center">            
                    <div className="col-md-5">
                    <input className="form-control" type="text" placeholder="Filter"  name="associateCodeNotInGroup"/>
                    <select className="form-control" multiple={true} value="Non Selected"/>
                  </div>
                    <div className="col-md-2 btn-group-vertical buttons">
                        <button type="button" className="btn btn-default" title="Move all">
                            <i className="glyphicon glyphicon-arrow-right"/>
                            <i className="glyphicon glyphicon-arrow-right"/>
                        </button>
                        <button type="button" className="btn btn-default" title="Move selected">
                            <i className="glyphicon glyphicon-arrow-right"/>
                        </button>
                        <button type="button" className="btn btn-default" title="Remove selected">
                            <i className="glyphicon glyphicon-arrow-left"/>
                        </button>
                        <button type="button" className="btn btn-default" title="Remove all">
                            <i className="glyphicon glyphicon-arrow-left"/>
                            <i className="glyphicon glyphicon-arrow-left"/>
                        </button>
                    </div>
                    <div className="col-md-5">
                    <input className="form-control" type="text" placeholder="Filter"  name="associateCodeNotInGroup"/>
                    <select className="form-control" multiple={true} key="non-selected">
                    {props.associateProjectGroup && props.associateProjectGroup.map((associateProjectGroup: AssociateProjectGroup) => {
                                return (
                             <option key={associateProjectGroup.id} value={associateProjectGroup.id}>{associateProjectGroup.code + '-' + associateProjectGroup.name}</option>
                    );
                })}
                </select>
                         </div>          
                </div>
            <div className="row"/>
            </div>
            </div>  
            <div className="form-group">
            <div className="col-sm-2">
        <button type="button" className="btn btn-secondary btn pull-right" onClick={() => props.loadAddBatch(false, '', '')}>Cancel</button>
            </div>
            <div className="col-sm-2">
            <button type="button" className="btn btn-primary btn pull-right">Add</button>
            </div>
           </div>
    </form>
    </div>
    </div>
    </div>
    );
};
export default AddBatchComponent;