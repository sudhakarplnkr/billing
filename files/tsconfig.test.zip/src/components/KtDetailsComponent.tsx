import * as React from 'react';
import { IKtDetailsProps, FileAssociatePlan } from '../models/KtDetails';

const KtDetailsComponent = (props: IKtDetailsProps): JSX.Element => {
    return (
        <table id="dtBasicExample" className="table table-striped table-bordered table-sm" cellSpacing="0">
            <thead>
                <tr>
                    <th className="th-sm">Week
                    </th>
                    <th className="th-sm">Day
                    </th>
                    <th className="th-sm">Titile
                    </th>
                    <th className="th-sm">Schedule Date
                    </th>
                    <th className="th-sm">Upload
                    </th>
                    <th className="th-sm">Download
                    </th>
                </tr>
            </thead>
            <tbody>
                {props.AssociatePlans && props.AssociatePlans.map((plan: FileAssociatePlan, index: number) =>
                    <tr key={index}>
                        <td>{plan.week}</td>
                        <td>{plan.day}</td>
                        <td>{plan.knowledgeTransferTitle}</td>
                        <td>{plan.scheduledDate.toDateString()}</td>
                        <td><input type="file" onChange={(event: any) => props.onChange(plan.id, event.target.files)} /><input type="button" onClick={() => props.uploadPlan(plan.id, plan.file)} value="Upload" className="btn" /></td>
                        <td className="download">
                            {plan.proof && <i onClick={() => props.downloadPlan(plan.proof, plan.id)} className="fa fa-download" />}
                        </td>
                    </tr>
                )}
            </tbody>
        </table>
    );
};

export default KtDetailsComponent;