import * as React from 'react';
import 'react-fa';
import { Role, Project, AccountRole, Team } from '../typings/ApiClient';
import { EmployeeDetail } from '../models/Associate';
import { isNumber, isDate, isNull } from 'util';

type Props = {
    role: Role[];
    project: Project[];
    accountRole: AccountRole[];
    loadTeam: (projectId: string) => void;
    team: Team[];
    loadAddAssociate: (isAddEdit: boolean) => void;
    frmField: { CognizantId: '', AssociateName: '' };
    formHandler: () => void;
    updateAssociateDetail: (employeeDetail?: EmployeeDetail) => void;
};

class AssociateAddComponent extends React.Component<Props, {}> {
    private constructor(props: Props) {
        super(props);
    }

    public onNumberChange = (value: string) => {
        if (isNumber(value)) {
            this.props.updateAssociateDetail({ rLGExperience: Number(value) });
        }
    }

    public onDateJChange = (value: string) => {
        if (isDate(value)) {
            this.props.updateAssociateDetail({ rLGDateofJoining: new Date(value) });
        }
    }

    public onDateLChange = (value: string) => {
        if (isDate(value)) {
            this.props.updateAssociateDetail({ rLGDateofLeaving: new Date(value) });
        }
    }

    public onProjectLoadChange = (value: string) => {
        if (!isNull(value)) {
            this.props.loadTeam(value);
            this.props.updateAssociateDetail({ projectId: value});
        }
    }

    public render() {
        return (
            <div className="container-fluid">
                <div className="col-md-12">
                    <form onSubmit={() => this.props.formHandler()}>
                        <fieldset>
                            <legend>Basic Information</legend>
                            <div className="form-group col-md-4">
                                <label>Cognizant ID</label>
                                <input type="text" className="form-control" onChange={(event) => this.props.updateAssociateDetail({ cognizantId: event.target.value })} id="CognizantId" />
                            </div>
                            <div className="form-group col-md-4">
                                <label>Associate Name</label>
                                <input type="text" className="form-control" onChange={(event) => this.props.updateAssociateDetail({ associateName: event.target.value })} id="AssociateName" />
                            </div>
                            <div className="form-group col-md-4">
                                <label>Cognizant Email Id</label>
                                <input type="text" className="form-control" onChange={(event) => this.props.updateAssociateDetail({ cognizantEmailId: event.target.value })} id="CognizantEmailId" />
                            </div>
                            <div className="form-group col-md-4">
                                <label>Cognizant Role</label>
                                <select className="form-control" onChange={(event) => this.props.updateAssociateDetail({ cognizantRoleId: event.target.value })} >
                                    <option key="0" value="Select Project">Select Cognizant Role</option>
                                    {this.props.role && this.props.role.map((role: Role) => {
                                        return (
                                            <option key={role.id} value={role.id}>{role.name}</option>
                                        );
                                    })}
                                </select>
                            </div>
                            <div className="form-group col-md-4 ">
                                <label>Project Name</label>
                                <select className="form-control" onChange={(event) => this.onProjectLoadChange(event.target.value)}>
                                    <option key="0" value="Select Project">Select Project</option>
                                    {this.props.project && this.props.project.map((project: Project) => {
                                        return (
                                            <option key={project.id} value={project.id}>{project.name}</option>
                                        );
                                    })}
                                </select>
                            </div>
                            <div className="form-group col-md-4">
                                <label>Team Name</label>
                                <select className="form-control" onChange={(event) => this.props.updateAssociateDetail({ teamId: event.target.value })}>
                                    <option key="0" value="Select Batch">Select Team</option>
                                    {this.props.team && this.props.team.map((team: Team) => {
                                        return (
                                            <option key={team.id} value={team.id}>{team.name}</option>
                                        );
                                    })}
                                </select>
                            </div>
                        </fieldset>
                        <fieldset>
                            <legend>Additional Information</legend>
                            <div className="form-group col-md-4">
                                <label> FNZ User Name </label>
                                <input type="text" className="form-control" onChange={(event) => this.props.updateAssociateDetail({ rLGUserName: event.target.value })} id="FNZUserName" />
                            </div>
                            <div className="form-group col-md-4">
                                <label> FNZ Staff ID  </label>
                                <input type="text" className="form-control" onChange={(event) => this.props.updateAssociateDetail({ rLGStaffId: event.target.value })} id="FNZStaffId" />
                            </div>
                            <div className="form-group col-md-4">
                                <label> FNZ Role </label>
                                <select className="form-control" onChange={(event) => this.props.updateAssociateDetail({ rLGRoleId: event.target.value })}>
                                    <option key="0" value="Select Project">Select FNZ Role</option>
                                    {this.props.accountRole && this.props.accountRole.map((accountRole: AccountRole) => {
                                        return (
                                            <option key={accountRole.id} value={accountRole.id}>{accountRole.name}</option>
                                        );
                                    })}
                                </select>
                            </div>
                            <div className="form-group col-md-4">
                                <label> FNZ Email </label>
                                <input type="text" className="form-control" onChange={(event) => this.props.updateAssociateDetail({ rLGEmail: event.target.value })} id="FNZEmail" />
                            </div>
                            <div className="form-group col-md-4">
                                <label>Asset No  </label>
                                <input type="text" className="form-control" onChange={(event) => this.props.updateAssociateDetail({ assetNo: event.target.value })} id="AssetNo" />
                            </div>
                            <div className="form-group col-md-4">
                                <label> Virtual Machine No </label>
                                <input type="text" className="form-control" onChange={(event) => this.props.updateAssociateDetail({ virtualMachineNo: event.target.value })} id="VirtualMachineNo" />
                            </div>
                            <div className="form-group col-md-4">
                                <label> Portfolio  </label>
                                <select className="form-control" onChange={(event) => this.props.updateAssociateDetail({ portfolio: event.target.value })} id="Portfolio">
                                    <option>Select Portfolio</option>
                                    <option>Yes</option>
                                    <option>No</option>
                                </select>
                            </div>
                            <div className="form-group col-md-4">
                                <label> FNZ Experience(months)  </label>
                                <input type="text" className="form-control" onChange={(event) => this.onNumberChange(event.target.value)} id="FNZExperience" />
                            </div>
                            <div className="form-group col-md-4">
                                <label>Billability  </label>
                                <select className="form-control" onChange={(event) => this.props.updateAssociateDetail({ billable: event.target.value })} id="Billable">
                                    <option>Select Billability</option>
                                    <option>Non-Billable</option>
                                    <option>Billable</option>
                                </select>
                            </div>
                            <div className="form-group col-md-4">
                                <label> Location </label>
                                <select className="form-control" onChange={(event) => this.props.updateAssociateDetail({ location: event.target.value })} id="Location">
                                    <option>Select Location</option>
                                    <option>Offshore</option>
                                    <option>Onshore</option>
                                </select>
                            </div>
                            <div className="form-group col-md-4">
                                <label>Contact Number  </label>
                                <input type="text" className="form-control" onChange={(event) => this.props.updateAssociateDetail({ contactNo: event.target.value })} id="ContactNo" />
                            </div>
                            <div className="form-group col-md-4">
                                <label> FNZ Date of Joining </label>
                                <input type="date" className="form-control" onChange={(event) => this.onDateJChange(event.target.value)} placeholder="dd-MM-yyyy" id="FNZDateofJoining" />
                            </div>
                            <div className="form-group col-md-4">
                                <label> FNZ Date of Leaving  </label>
                                <input type="date" className="form-control" onChange={(event) => this.onDateLChange(event.target.value)} placeholder="dd-MM-yyyy" id="FNZDateofLeaving" />
                            </div>
                        </fieldset>
                        <div className="form-group  col-md-6 col-md-offset-5">
                            <button name="add" type="submit" value="add" className="btn btn-primary">Add</button>&nbsp;
                            <button name="back" type="submit" onClick={() => this.props.loadAddAssociate(false)} value="add" className="btn btn-danger">Back</button>
                        </div>
                    </form>
                </div>
            </div>
        );
    }
}

export default AssociateAddComponent;