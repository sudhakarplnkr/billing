import * as React from 'react';
import { Dashboard } from '../typings/ApiClient';
import { CirclePie } from 'salad-ui.chart';

type Props = {
    dashboard: Dashboard[];
};

const DashboardComponent = ({ dashboard: dashboards }: Props) => {
    return (
        <div>
            {dashboards && dashboards.map((dashboard: Dashboard, index: number) => {
                const option = {
                    width: 100,
                    height: 100,
                    strokeWidth: 7,
                    percent: dashboard.completedCount,
                    strokeColor: 'rgb(31, 207, 101)'
                };
                return <div key={index} className="col-sm-3">
                    <div className="col-sm-12">
                        <h3>{dashboard.projectName}</h3>
                    </div>
                    <div className="col-sm-4">
                        <CirclePie {...option} />
                    </div>
                    <div className="col-sm-6">
                        <ul>
                            <li>{dashboard.roleName}:{dashboard.completedCount}/{dashboard.count}</li>
                        </ul>
                    </div>
                </div>;
            })}

        </div>
    );
};

export default DashboardComponent;
