import * as React from 'react';
import 'react-fa';
import { Associate, KnowledgeTransfer, Mode, Role } from '../typings/ApiClient';

type Props = {
    associate: Associate[],
    knowledgeTransfer: KnowledgeTransfer[];
    mode: Mode[];
    role: Role[];
    loadAddPlan: (addPlan: Boolean) => void; 
};

const AddPlanComponent = (props: Props) => {
  return (
    <div className="col-md-12" role="dialog">
      <div className="modal-dialog">
        <div className="modal-content">
          <form className="form-horizontal">
            <div className="modal-header">
        <div>
            <h1>Add New Plan</h1>
        </div>
        </div>
        <div className="modal-body">
       <div className="md-dialog-container">
            <div className="form-group">
            <label className="control-label col-sm-2">KT Title:</label>
                <div className="col-sm-10">
                    <select id="KnowledgeTransfer"className="form-control">
                        <option key="0">Select Title</option>
                        {props.knowledgeTransfer && props.knowledgeTransfer.map((knowledgeTransfer: KnowledgeTransfer) => {
                                return (
                                    <option key={knowledgeTransfer.id} value={knowledgeTransfer.id}>{knowledgeTransfer.name}</option>
                                );
                            })}
                    </select>
                </div>
            </div>
            <div className="form-group">
                <label className="control-label col-sm-2">Role:</label>
                <div className="col-sm-4">
                    <select id="Role" className="form-control">
                        <option key="0">Select Role</option>
                        {props.role && props.role.map((role: Role) => {
                                return (
                                    <option key={role.id} value={role.id}>{role.name}</option>
                                );
                            })}
                     </select>
                </div>            
            </div>
            <div className="form-group">
                <label className="control-label col-sm-2">Mode:</label>
                <div className="col-sm-4">
                    <select id="Mode" className="form-control">
                        <option  key="0">Select Mode</option>
                        {props.mode && props.mode.map((mode: Mode) => {
                                return (
                                    <option key={mode.id} value={mode.id}>{mode.name}</option>
                                );
                            })}
                    </select>
                </div>
                <label className="control-label col-sm-2">Owner:</label>
                <div className="col-sm-4">
                    <select id="Owner" className="form-control">
                        <option>Select Owner</option>
                        {props.associate && props.associate.map((associate: Associate) => {
                                return (
                                    <option key={associate.id} value={associate.id}>{associate.name}</option>
                                );
                            })}
                     </select>
                </div>
            </div>
            <div className="form-group">
                <label className="control-label col-sm-2">Reference:</label>
                <div className="col-sm-10">
                    <textarea className="form-control" placeholder="Reference" id="Reference"/>
                </div>
            </div>
            <div className="form-group">
                <label className="control-label col-sm-1">Week:</label>
                <div className="col-sm-2">
                    <input type="text" className="form-control" placeholder="Week" id="Week"/>
                </div>      
                <label className="control-label col-sm-1">Day:</label>
                <div className="col-sm-2">
                    <input type="text" className="form-control" placeholder="Day" id="Day"/>
                </div>
                <label className="control-label col-sm-2">Scheduled Date:</label>
                <div className="col-sm-4">
                    <input type="date" className="form-control" placeholder="dd-MM-yyyy" />
                 </div>
            </div>
        <div className="form-group">
        <div className="col-sm-2">
        <button type="button" className="btn btn-secondary btn pull-right" onClick={() => props.loadAddPlan(false)}>Cancel</button>
        </div>
        <div className="col-sm-2">
        <button type="button" className="btn btn-primary btn pull-right">Add</button>
        </div>
        </div>
        </div>
        </div>
    </form>
    </div>
    </div>
    </div>
    );
};
export default AddPlanComponent;