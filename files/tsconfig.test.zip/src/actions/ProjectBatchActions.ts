import { Project, ProjectGroup, Associate, KnowledgeTransfer, Mode, Role, AssociateProjectGroup } from '../typings/ApiClient';
import service from '../services/Service';
import { ProjectGroupPlanWithStatus } from '../typings/ApiClient';
export const LOAD_PROJECT = 'project/LOAD_PROJECT';
export const PROJECT_FAILED_RESPONSE = 'project/PROJECT_FAILED_RESPONSE';
export const LOAD_BATCH = 'batch/LOAD_BATCH';
export const BATCH_FAILED_RESPONSE = 'batch/BATCH_FAILED_RESPONSE';
export const LOAD_PROJECTGROUPPLAN = 'projectGroup/LOAD_PROJECTGROUPPLAN';
export const PROJECTGROUPPLAN_FAILED_RESPONSE = 'projectGroup/PROJECTGROUPPLAN_FAILED_RESPONSE';
export const LOAD_ADD_PLAN = 'addPlan/LOAD_ADD_PLAN';
export const LOAD_ASSOCIATE_ADD_PLAN = 'addPlan/LOAD_ASSOCIATE_ADD_PLAN';
export const ASSOCIATE_ADD_PLAN_FAILED_RESPONSE = 'addPlan/ASSOCIATE_ADD_PLAN_FAILED_RESPONSE';
export const LOAD_KNOWLEDGE_TRANSFER = 'addPlan/LOAD_KNOWLEDGE_TRANSFER';
export const KNOWLEDGE_TRANSFER_FAILED_RESPONSE = 'addPlan/KNOWLEDGE_TRANSFER_FAILED_RESPONSE';
export const LOAD_MODE = 'addPlan/LOAD_MODE';
export const MODE_FAILED_RESPONSE = 'addPlan/MODE_FAILED_RESPONSE';
export const LOAD_ROLE_ADD_PLAN = 'addPlan/LOAD_ROLE_ADD_PLAN';
export const ROLE_ADD_PLAN_FAILED_RESPONSE = 'addPlan/ROLE_ADD_PLAN_FAILED_RESPONSE';
export const SHOW_MODAL = 'SHOW_MODAL';
export const LOAD_ADD_BATCH = 'addBatch/LOAD_ADD_BATCH';
export const LOAD_ASSOCIATE_ADD_BATCH = 'addBatch/LOAD_ASSOCIATE_ADD_BATCH';
export const ASSOCIATE_ADD_BATCH_FAILED_RESPONSE = 'addBatch/ASSOCIATE_ADD_BATCH_FAILED_RESPONSE';

export const loadProjects = () => {
    return (dispatch: any) => {
        service.ProjectClient.get()
            .then((response: Project[]) => {
                dispatch({
                    type: LOAD_PROJECT,
                    payload: response
                });
            }).catch(() => {
                dispatch({
                    type: PROJECT_FAILED_RESPONSE,
                    payload: []
                });
            });
    };
};

export const loadBatches = (projectId: string) => {
    return (dispatch: any) => {
        service.ProjectGroupClient.query(projectId)
            .then((response: ProjectGroup[]) => {
                dispatch({
                    type: LOAD_BATCH,
                    payload: { batch: response, projectId: projectId }
                });
            }).catch(() => {
                dispatch({
                    type: BATCH_FAILED_RESPONSE,
                    payload: { batch: [], projectId: projectId }
                });
            });
    };
};

export const loadProjectGroupPlan = (batchId: string) => {
    return (dispatch: any) => {
        service.ProjectGroupPlanClient.query(batchId)
            .then((response: ProjectGroupPlanWithStatus[]) => {
                dispatch({
                    type: LOAD_PROJECTGROUPPLAN,
                    payload: { team: response, batchId: batchId }
                });
            }).catch(() => {
                dispatch({
                    type: PROJECTGROUPPLAN_FAILED_RESPONSE,
                    payload: { team: [], batchId: batchId }
                });
            });
    };
};

export const showModal = (show: Boolean) => {
    return (dispatch: any) => {
        dispatch({
            type: SHOW_MODAL,
            payload: show
        });
    };
};

export const loadAddPlan = (addPlan: Boolean) => {
    return (dispatch: any) => {
        dispatch({
            type: LOAD_ADD_PLAN,
            payload: addPlan
        });
        service.AssociateClient.get()
            .then((response: Associate[]) => {
                dispatch({
                    type: LOAD_ASSOCIATE_ADD_PLAN,
                    payload: response
                });
            }).catch(() => {
                dispatch({
                    type: ASSOCIATE_ADD_PLAN_FAILED_RESPONSE,
                    payload: []
                });
            });
        service.KnowledgeTransferClient.get()
            .then((response: KnowledgeTransfer[]) => {
                dispatch({
                    type: LOAD_KNOWLEDGE_TRANSFER,
                    payload: response
                });
            }).catch(() => {
                dispatch({
                    type: KNOWLEDGE_TRANSFER_FAILED_RESPONSE,
                    payload: []
                });
            });
        service.ModeClient.get()
            .then((response: Mode[]) => {
                dispatch({
                    type: LOAD_MODE,
                    payload: response
                });
            }).catch(() => {
                dispatch({
                    type: MODE_FAILED_RESPONSE,
                    payload: []
                });
            });
        service.RoleClient.get()
            .then((response: Role[]) => {
                dispatch({
                    type: LOAD_ROLE_ADD_PLAN,
                    payload: response
                });
            }).catch(() => {
                dispatch({
                    type: ROLE_ADD_PLAN_FAILED_RESPONSE,
                    payload: []
                });
            });
    };
};

export const loadAddBatch = (addBatch: Boolean, projectId: string, projectGroupId: string) => {
    return (dispatch: any) => {
        dispatch({
            type: LOAD_ADD_BATCH,
            payload: addBatch
        });
        service.AssociateClient.query(projectId, projectGroupId)
            .then((response: AssociateProjectGroup[]) => {
                dispatch({
                    type: LOAD_ASSOCIATE_ADD_BATCH,
                    payload: response
                });
            }).catch(() => {
                dispatch({
                    type: ASSOCIATE_ADD_BATCH_FAILED_RESPONSE,
                    payload: []
                });
            });
    };
};