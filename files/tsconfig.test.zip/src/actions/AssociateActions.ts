﻿import { AssociateDetails, Role, Project, AccountRole, Team } from '../typings/ApiClient';
import service from '../services/Service';
import { EmployeeDetail } from '../models/Associate';

export const ASSOCIATE_FAILED_RESPONSE = 'associate/ASSOCIATE_FAILED_RESPONSE';
export const LOAD_ASSOCIATE = 'associate/LOAD_ASSOCIATE';
export const ADD_ASSOCIATE = 'associate/ADD_ASSOCIATE';
export const LOAD_ROLE = 'associate/LOAD_ROLE';
export const LOAD_ROLE_FAILED_RESPONSE = 'associate/LOAD_ROLE_FAILED_RESPONSE';
export const LOAD_PROJECT = 'associate/LOAD_PROJECT';
export const LOAD_PROJECT_FAILED_RESPONSE = 'associate/LOAD_PROJECT_FAILED_RESPONSE';
export const LOAD_ACCOUNT_ROLE = 'associate/LOAD_ACCOUNT_ROLE';
export const LOAD_ACCOUNT_ROLE_FAILED_RESPONSE = 'associate/LOAD_ACCOUNT_ROLE_FAILED_RESPONSE';
export const LOAD_TEAM = 'project/LOAD_TEAM';
export const LOAD_TEAM_FAILED_RESPONSE = 'project/LOAD_TEAM_FAILED_RESPONSE';
export const ADD_DATA_ASSOCIATE = 'project/ADD_DATA_ASSOCIATE';
export const ADD_DATA_ASSOCIATE_FAILED_RESPONSE = 'project/ADD_DATA_ASSOCIATE_FAILED_RESPONSE';
export const UPDATE_ASSOCIATE_DETAILS = 'associate/UPDATE_ASSOCIATE_DETAILS';

export type Action = {
    type: string,
    payload: AssociateDetails[]
};

export const loadAssociate = () => {
    return (dispatch: any) => {
        service.AssociateDetailsClient.get('0')
            .then((response: AssociateDetails[]) => {
                dispatch({
                    type: LOAD_ASSOCIATE,
                    payload: response
                });
            }).catch(() => {
                dispatch({
                    type: ASSOCIATE_FAILED_RESPONSE
                });
            });
    };
};

export const loadAddAssociate = (isAddEdit: boolean) => {
    return (dispatch: any) => {
        dispatch({
            type: ADD_ASSOCIATE,
            payload: isAddEdit
        });
        service.RoleClient.get()
            .then((response: Role[]) => {
                dispatch({
                    type: LOAD_ROLE,
                    payload: response
                });
            }).catch(() => {
                dispatch({
                    type: LOAD_ROLE_FAILED_RESPONSE,
                    payload: []
                });
            });
        service.ProjectClient.get()
            .then((response: Project[]) => {
                dispatch({
                    type: LOAD_PROJECT,
                    payload: response
                });
            }).catch(() => {
                dispatch({
                    type: LOAD_PROJECT_FAILED_RESPONSE,
                    payload: []
                });
            });
        service.AccountRoleClient.getRole()
            .then((response: AccountRole[]) => {
                dispatch({
                    type: LOAD_ACCOUNT_ROLE,
                    payload: response
                });
            }).catch(() => {
                dispatch({
                    type: LOAD_ACCOUNT_ROLE_FAILED_RESPONSE,
                    payload: []
                });
            });
    };
};

export const loadTeam = (projectId: string) => {
    return (dispatch: any) => {
        service.ProjectTeamClient.getTeamList(projectId)
            .then((response: Team[]) => {
                dispatch({
                    type: LOAD_TEAM,
                    payload: response
                });
            }).catch(() => {
                dispatch({
                    type: LOAD_TEAM_FAILED_RESPONSE,
                    payload: []
                });
            });
    };
};

export const addAssociateDetail = (associateDetails: AssociateDetails) => {
    return (dispatch: any) => {
        service.AssociateDetailsClient.post(associateDetails)
            .then((response: any) => {
                dispatch({
                    type: ADD_DATA_ASSOCIATE,
                    payload: response
                });
            }).catch(() => {
                dispatch({
                    type: ADD_DATA_ASSOCIATE_FAILED_RESPONSE,
                    payload: []
                });
            });
    };
};

export const updateAssociateDetail = (employeeDetail: EmployeeDetail) => {
    return (dispatch: any) => {
        dispatch({
            type: UPDATE_ASSOCIATE_DETAILS,
            payload: employeeDetail
        });
    };
};