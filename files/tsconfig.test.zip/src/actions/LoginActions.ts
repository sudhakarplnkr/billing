import SessionManagement from '../utils/SessionManagement';
import service from '../services/Service';
import { UserRole } from '../typings/ApiClient';

export const ON_LOGIN = 'login/ON_LOGIN';
export const CHANGE_ASSOCIATE_ID = 'login/CHANGE_ASSOCIATE_ID';

export const onLogin = (associateId?: number) => {
    SessionManagement.SetToken(btoa(`${associateId}:`));
    return (dispatch: any) => {
        service.UserRoleClient.get().then((response: UserRole[]) => {
            const isAdmin = response.filter(u => u.role === 'Admin').length === 1;
            dispatch({
                type: ON_LOGIN,
                payload: { associateId: associateId, isAdmin: isAdmin }
            });
        });
    };
};

export const onAssociateIdChange = (associateId?: number) => {
    return (dispatch: any) => {
        dispatch({
            type: CHANGE_ASSOCIATE_ID,
            payload: associateId
        });
    };
};
