import service from '../services/Service';
import { FileAssociatePlan } from '../models/KtDetails';
import { FileParameter } from '../typings/FileManagementService';

export const GET_ASSOCIATEPLAN = 'ktdetails/GET_ASSOCIATEPLAN';
export const UPDATE_ASSOCIATEPLAN = 'ktdetails/UPDATE_ASSOCIATEPLAN';
export const UPLOAD_ASSOCIATEPLAN = 'ktdetails/UPLOAD_ASSOCIATEPLAN';
export const GET_ASSOCIATEPLAN_FAILED = 'ktdetails/GET_ASSOCIATEPLAN_FAILED';

export const uploadPlan = (associatePlanId: string, file: any) => {
    const fileParameter = {
        data: file,
        fileName: associatePlanId
    } as FileParameter;
    return (dispatch: any) => {
        service.FileManagementClient.upload(associatePlanId, fileParameter)
            .then((response: any) => {
                dispatch({
                    type: UPLOAD_ASSOCIATEPLAN,
                    payload: {fileData: response, associateId: associatePlanId}
                });
            }).catch(() => {
                dispatch({
                    type: GET_ASSOCIATEPLAN_FAILED
                });
            });
    };
};

export const onFileChange = (associatePlans: FileAssociatePlan[], associatePlanId: string, file: any) => {
    const plans: FileAssociatePlan[] = [...associatePlans];
    const updatedPlanIndex = plans.findIndex(single => single.id === associatePlanId);
    if (updatedPlanIndex !== -1) {
        plans[updatedPlanIndex].file = file;
        return (dispatch: any) => {
            dispatch({
                type: UPDATE_ASSOCIATEPLAN,
                payload: plans
            });
        };
    }
    return (dispatch: any) => {
        dispatch({
            type: UPDATE_ASSOCIATEPLAN,
            payload: associatePlans
        });
    };
};

export const getAssociatePlans = () => {
    return (dispatch: any) => {
        service.AssociatePlanClient.query()
            .then((response: FileAssociatePlan[]) => {
                dispatch({
                    type: GET_ASSOCIATEPLAN,
                    payload: response
                });
            }).catch(() => {
                dispatch({
                    type: GET_ASSOCIATEPLAN_FAILED
                });
            });
    };
};
