import { Project, ProjectGroup, Associate, KnowledgeTransfer, Mode, Role, AssociateProjectGroup, AssociatePlan, ProcessCreateProjectGroup, ProcessUpdateProjectGroup } from '../typings/ApiClient';
import service from '../services/Service';
import { ProjectGroupPlanWithStatus } from '../typings/ApiClient';
import { IProjectBatchModel } from '../models/ProjectBatch';
export const UPDATE_PROJECT_BATCH = 'associateStatus/UPDATE_PROJECT_BATCH';

export const loadProjects = () => {
    return (dispatch: any) => {
        service.ProjectClient.get()
            .then((response: Project[]) => {
                dispatch({
                    type: UPDATE_PROJECT_BATCH,
                    payload: { project: response }
                });
            }).catch(() => {
                dispatch({
                    type: UPDATE_PROJECT_BATCH,
                    payload: { project: [] }
                });
            });
    };
};

export const loadBatches = (projectId: string) => {
    return (dispatch: any) => {
        service.ProjectGroupClient.query(projectId)
            .then((response: ProjectGroup[]) => {
                dispatch({
                    type: UPDATE_PROJECT_BATCH,
                    payload: { batch: response, selectedProjectId: projectId }
                });
            }).catch(() => {
                dispatch({
                    type: UPDATE_PROJECT_BATCH,
                    payload: { batch: [], selectedProjectId: projectId }
                });
            });
    };
};

export const loadProjectGroupPlan = (batchId: string) => {
    return (dispatch: any) => {
        service.ProjectGroupPlanClient.query(batchId)
            .then((response: ProjectGroupPlanWithStatus[]) => {
                dispatch({
                    type: UPDATE_PROJECT_BATCH,
                    payload: { projectGroupPlan: response, selectedBatchId: batchId }
                });
            }).catch(() => {
                dispatch({
                    type: UPDATE_PROJECT_BATCH,
                    payload: { projectGroupPlan: [], selectedBatchId: batchId }
                });
            });
    };
};

export const showModal = (show: Boolean) => {
    return (dispatch: any) => {
        dispatch({
            type: UPDATE_PROJECT_BATCH,
            payload: { showDialog: show }
        });
    };
};

export const loadAddPlan = (addPlan: Boolean, planTitle: string) => {
    return (dispatch: any) => {
        dispatch({
            type: UPDATE_PROJECT_BATCH,
            payload: { showAddPlan: addPlan, planTitle: planTitle }
        });
        service.AssociateClient.get()
            .then((response: Associate[]) => {
                dispatch({
                    type: UPDATE_PROJECT_BATCH,
                    payload: { associate: response }
                });
            }).catch(() => {
                dispatch({
                    type: UPDATE_PROJECT_BATCH,
                    payload: { associate: [] }
                });
            });
        service.KnowledgeTransferClient.get()
            .then((response: KnowledgeTransfer[]) => {
                dispatch({
                    type: UPDATE_PROJECT_BATCH,
                    payload: { knowledgeTransfer: response }
                });
            }).catch(() => {
                dispatch({
                    type: UPDATE_PROJECT_BATCH,
                    payload: { knowledgeTransfer: [] }
                });
            });
        service.ModeClient.get()
            .then((response: Mode[]) => {
                dispatch({
                    type: UPDATE_PROJECT_BATCH,
                    payload: { mode: response }
                });
            }).catch(() => {
                dispatch({
                    type: UPDATE_PROJECT_BATCH,
                    payload: { mode: [] }
                });
            });
        service.RoleClient.get()
            .then((response: Role[]) => {
                dispatch({
                    type: UPDATE_PROJECT_BATCH,
                    payload: { role: response }
                });
            }).catch(() => {
                dispatch({
                    type: UPDATE_PROJECT_BATCH,
                    payload: { role: [] }
                });
            });
    };
};

export const updateProjectBatch = (projectBatchModel: IProjectBatchModel) => {
    return (dispatch: any) => {
        dispatch({
            type: UPDATE_PROJECT_BATCH,
            payload: projectBatchModel
        });
    };
};

export const loadAddBatch = (addBatch: Boolean, projectId: string, projectGroupId: string) => {
    return (dispatch: any) => {
        dispatch({
            type: UPDATE_PROJECT_BATCH,
            payload: { showAddBatch: addBatch }
        });
        service.AssociateClient.query(projectId, projectGroupId)
            .then((response: AssociateProjectGroup[]) => {
                dispatch({
                    type: UPDATE_PROJECT_BATCH,
                    payload: { associateProjectGroup: response }
                });
            }).catch(() => {
                dispatch({
                    type: UPDATE_PROJECT_BATCH,
                    payload: { associateProjectGroup: [] }
                });
            });
    };
};

export const createBatch = (processCreateProjectGroup: ProcessCreateProjectGroup) => {
    return () => {
        service.ProjectGroupClient.post(processCreateProjectGroup);        
    };
};

export const saveBatch = (id: string, processUpdateProjectGroup: ProcessUpdateProjectGroup) => {
    return (dispatch: any) => {
        dispatch({
            type: UPDATE_PROJECT_BATCH,
            payload: { showStatus: false }
        });
        service.ProjectGroupClient.put(id, processUpdateProjectGroup);
    };
};

export const deleteBatch = (id: string) => {
    return () => {        
        service.ProjectGroupClient.delete(id);
    };
};

export const loadAssociateStatus = (groupPlan: Boolean, groupPlanId: string) => {
    return (dispatch: any) => {
        dispatch({
            type: UPDATE_PROJECT_BATCH,
            payload: { showStatus: groupPlan }
        });
        service.AssociatePlanClient.getAssociatePlanStatus(groupPlanId)
            .then((response: AssociatePlan[]) => {
                dispatch({
                    type: UPDATE_PROJECT_BATCH,
                    payload: { associatePlan: response }
                });
            }).catch(() => {
                dispatch({
                    type: UPDATE_PROJECT_BATCH,
                    payload: { associatePlan: [] }
                });
            });
    };
};