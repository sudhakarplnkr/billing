import { combineReducers } from 'redux';
import dashboard from './DashboardReducer';
import LoginReducer from './LoginReducer';
import AppReducer from './AppReducer';
import KtDetailsReducer from './KtDetailsReducer';
import AssociateReducer from './AssociateReducer';
import ProjectBatchReducer from './ProjectBatchReducer';
import {reducer as toastrReducer} from 'react-redux-toastr';

export default combineReducers({
  app: AppReducer,
  data: dashboard,
  login: LoginReducer,
  ktDetails: KtDetailsReducer,
  associate: AssociateReducer,
  projectBatch: ProjectBatchReducer,
  isAddEditValue: AssociateReducer,
  roleAddData: AssociateReducer,
  projectAddData: AssociateReducer,
  accountRoleData: AssociateReducer,
  teamData: AssociateReducer,
  showDialogValue: AssociateReducer,
  associateDetailsData: AssociateReducer,  
  toastr: toastrReducer
});
