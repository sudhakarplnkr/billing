import { Project, ProjectGroup, ProjectGroupPlanWithStatus, Associate, KnowledgeTransfer, Mode, Role, AssociateProjectGroup, AssociatePlan, ProcessCreateProjectGroup, ProcessUpdateProjectGroup } from '../typings/ApiClient';

export interface IProjectProps {
    loadProjects(): void;
    loadBatches(projectId: string): void;
    loadProjectGroupPlan(batchId: string): void;
    showModal(show: Boolean): void;
    loadAddPlan(addPlan: Boolean, planTitle: string): void;
    loadAddBatch(addBatch: Boolean, projectId: string, projectGroupId: string): void;
    loadAssociateStatus(groupPlan: Boolean, groupPlanId: string): void;
    updateProjectBatch: (projectBatchModel: IProjectBatchModel) => void;
    createBatch: (processCreateProjectGroup: ProcessCreateProjectGroup) => void;
    saveBatch: (id: string, processUpdateProjectGroup: ProcessUpdateProjectGroup) => void;
    deleteBatch: (id: string) => void;
    projectBatchModel: IProjectBatchModel;
    loadAddBatch: (addBatch: Boolean, projectId: string, projectGroupId: string) => void;
}
export interface IProjectState {
    projectBatchModel: IProjectBatchModel;
}

export interface IProjectBatchModel {
    projectGroupPlan?: ProjectGroupPlanWithStatus[];
    project?: Project[];
    batch?: ProjectGroup[];
    showDialog?: Boolean;
    showAddPlan?: Boolean;
    showAddBatch?: Boolean;
    showStatus?: Boolean;
    selectedProjectId?: string;
    selectedBatchId?: string;
    planTitle?: string;
    associate?: Associate[];
    knowledgeTransfer?: KnowledgeTransfer[];
    mode?: Mode[];
    role?: Role[];
    associateProjectGroup?: AssociateProjectGroup[];
    associatePlan?: AssociatePlan[];
    selectedProjectBatch?: string[];
    projectGroup?: string;
    message?: string;
    selectedProject?: Project;
    selectedBatch?: ProjectGroup;
    processProjectGroup?: ProcessProjectGroup;
}

export interface ProcessProjectGroup {
    projectId?: string;
    name?: string | undefined;
    startDate?: Date;
    addAssociates?: Associate[] | undefined;
    projectGroupId?: string;
    deleteAssociates?: Associate[] | undefined;
}