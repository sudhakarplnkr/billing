import { AssociatePlan } from '../typings/ApiClient';
import { FileParameter } from '../typings/FileManagementService';

export interface IKtDetailsProps {
    AssociatePlans?: FileAssociatePlan[];
    getAssociatePlans?: () => void;
    onChange: (associatePlanId: string, file: FileList) => void;
    uploadPlan: (associatePlanId: string, fileParameter: FileParameter) => void;
    onFileChange?: (associatePlans: FileAssociatePlan[], associatePlanId: string, file: any) => void;
    downloadPlan: (file?: string, fileName?: string) => void;
}

export interface IKtDetailsState {
    AssociatePlans: FileAssociatePlan[];
}

export interface FileAssociatePlan extends AssociatePlan {
    file: FileParameter;
    fileData?: string;
}