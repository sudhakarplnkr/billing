import * as React from 'react';
import 'react-fa';
import { AssociatePlan } from '../typings/ApiClient';
import { IProjectBatchModel } from '../models/ProjectBatch';

type Props = {
    loadAssociateStatus: (groupPlan: Boolean, groupPlanId: string) => void;
    projectBatchModel: IProjectBatchModel;
};
const AssociateStatusComponent = (props: Props) => {
    return (
        <div className="col-md-12" role="dialog" >
            <div className="modal-dialog">
                <div className="modal-content">
                    <form className="form-horizontal">
                        <div className="modal-header">
                            <div>
                                <h1>Associate Status</h1>
                            </div>
                        </div>
                        <div className="modal-body" >
                            <div className="md-dialog-container">
                                <table className="table table-striped">
                                    <thead>
                                        <tr>
                                            <th>Associate</th>
                                            <th>Completed Date</th>
                                            <th>Proof</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {props.projectBatchModel.associatePlan && props.projectBatchModel.associatePlan.map((associatePlan: AssociatePlan, index) => {
                                            return (
                                                <tr key={index}>
                                                    <td>{associatePlan.associateName}</td>
                                                    <td>{associatePlan.scheduledDate.toDateString()}</td>
                                                    <td>{associatePlan.proofType}</td>
                                                </tr>
                                            );
                                        })}
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        <div className="container-fluid">
                            <div className="col-md-12">
                                <button type="button" className="btn btn-secondary btn pull-right" onClick={() => props.loadAssociateStatus(false, ' ')}>Close</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    );
};
export default AssociateStatusComponent;