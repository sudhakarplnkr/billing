import * as React from 'react';
import 'react-fa';
import { Project } from '../typings/ApiClient';
import { ProjectGroup } from '../typings/ApiClient';
import { ProjectGroupPlanWithStatus } from '../typings/ApiClient';
import ModalComponent from './ModalComponent';
import AddPlanComponent from './AddPlanComponent';
import AddBatchComponent from './AddBatchComponent';
import AssociateStatusComponent from './AssociateStatusComponent';
import { IProjectBatchModel } from '../models/ProjectBatch';

type Props = {
    loadProjectGroupPlan: (batchId: string) => void;
    loadBatches: (projectId: string) => void;
    showModal: (show: Boolean) => void;
    loadAddPlan: (addPlan: Boolean, planTitle: string) => void;
    loadAssociateStatus: (groupPlan: Boolean, groupPlanId: string) => void;
    updateProjectBatch: (projectBatchModel: IProjectBatchModel) => void;
    projectBatchModel: IProjectBatchModel;
    saveBatch: () => void;
    loadAddBatch: (addBatch: boolean) => void;
    deleteBatch: () => void;
};

const ProjectBatchComponent = (props: Props) => {
    return (
        <div className="container-fluid">
            <div className="col-md-12" style={{ position: 'absolute' }}>
                {props.projectBatchModel.showDialog ? <ModalComponent onOk={() => props.deleteBatch()} showModal={(showDialog: boolean) => props.showModal(showDialog)} /> : ''}
            </div>
            <div className="col-md-12" style={{ position: 'absolute' }}>
                {props.projectBatchModel.showAddPlan ?
                    <AddPlanComponent
                        projectBatchModel={props.projectBatchModel}
                        loadAddPlan={(addPlan: boolean, planTitle: string) => props.loadAddPlan(addPlan, planTitle)}
                    /> : ''}
            </div>
            <div className="col-md-12" style={{ position: 'absolute' }}>
                {props.projectBatchModel.showAddBatch ?
                    <AddBatchComponent
                        updateProjectBatch={(projectBatchModel: IProjectBatchModel) => props.updateProjectBatch(projectBatchModel)}
                        saveBatch={() => props.saveBatch()}
                        projectBatchModel={props.projectBatchModel}
                    /> : ''}
            </div>
            <div className="col-md-12" style={{ position: 'absolute' }}>
                {props.projectBatchModel.showStatus ?
                    <AssociateStatusComponent
                        projectBatchModel={props.projectBatchModel}
                        loadAssociateStatus={(groupPlan: Boolean, groupPlanId: string) => props.loadAssociateStatus(groupPlan, groupPlanId)}
                    /> : ''}
            </div>
            <div className="col-md-12" style={{ position: 'static' }}>
                <div className="col-md-1">
                    <h5> Project </h5>
                </div>
                <div className="col-md-4">
                    <div className="dropdown">
                        <select
                            className="form-control"
                            value={props.projectBatchModel.selectedProject ? props.projectBatchModel.selectedProject.id : '0'}
                            onChange={(event) => props.loadBatches(event.target.value)}
                        >
                            <option key="0" value="Select Project">Select Project</option>
                            {props.projectBatchModel.project && props.projectBatchModel.project.map((project: Project) => {
                                return (
                                    <option key={project.id} value={project.id}>{project.name}</option>
                                );
                            })}
                        </select>
                    </div>
                </div>
                <div className="col-md-1">
                    <h5> Batch </h5>
                </div>
                <div className="col-md-4">
                    <div className="dropdown" key="option">
                        <select
                            key="values"
                            className="form-control"
                            onChange={(event) => props.loadProjectGroupPlan(event.target.value)}
                        >
                            <option key="0" value="Select Batch">Select Batch</option>
                            {props.projectBatchModel.batch && props.projectBatchModel.batch.map((batch: ProjectGroup) => {
                                return (
                                    <option key={batch.id} value={batch.id}>{batch.name}</option>
                                );
                            })}
                        </select>
                    </div>
                </div>
                <div className="col-md-1">
                    {props.projectBatchModel.selectedProject && props.projectBatchModel.selectedBatch ?
                        <button type="button" className="btn btn-primary" onClick={() => props.loadAddBatch(true)}>Edit Batch</button>
                        : props.projectBatchModel.selectedProject ?
                            <button type="button" className="btn btn-primary" onClick={() => props.loadAddBatch(true)}>Create Batch</button>
                            : ''
                    }
                </div>
                <div className="col-md-1">
                    {props.projectBatchModel.selectedProject && props.projectBatchModel.selectedBatch &&
                        <button type="button" className="btn btn-secondary" onClick={() => props.showModal(true)}>Delete Batch</button>
                    }
                </div>
            </div>
            <div className="col-md-12">
                <button type="button" className="btn btn-link btn pull-right" onClick={() => props.loadAddPlan(true, 'Add Plan')}>Add Plan</button>
            </div>
            <div>
                <table id="dtBasicExample" className="table table-striped table-bordered table-sm" cellSpacing="0">
                    <thead>
                        <tr>
                            <th className="th-sm">Week
                    </th>
                            <th className="th-sm">Day
                    </th>
                            <th className="th-sm">Title
                    </th>
                            <th className="th-sm">Mode
                    </th>
                            <th className="th-sm">Owner
                    </th>
                            <th className="th-sm">Scheduled Date
                    </th>
                            <th className="th-sm">Status
                    </th>
                            <th className="th-sm">Action
                    </th>
                        </tr>
                    </thead>
                    <tbody>
                        {props.projectBatchModel.projectGroupPlan && props.projectBatchModel.projectGroupPlan.map((projectGroupPlan: ProjectGroupPlanWithStatus, index: number) => {
                            return (
                                <tr key={index}>
                                    <td>{projectGroupPlan.week}</td>
                                    <td>{projectGroupPlan.day}</td>
                                    <td>{projectGroupPlan.knowledgeTransferName}</td>
                                    <td>{projectGroupPlan.modeName}</td>
                                    <td>{projectGroupPlan.ownerName}</td>
                                    <td>{projectGroupPlan.scheduledDate.toLocaleDateString()}</td>
                                    <td><i className="btn btn-link" onClick={() => props.loadAssociateStatus(true, projectGroupPlan.id)}>{projectGroupPlan.completedCount}/{projectGroupPlan.totalCount}</i></td>
                                    <td><i className="fa fa-edit" onClick={() => props.loadAddPlan(true, 'Edit Plan')} />&nbsp;<i className="fa fa-remove" onClick={() => props.loadAddPlan(true, 'Confirm to Delete?')} /></td>
                                </tr>
                            );
                        })}
                    </tbody>
                </table>
            </div>
        </div>
    );
};
export default ProjectBatchComponent;
