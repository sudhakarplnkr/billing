import * as React from 'react';
import 'react-fa';
import { AssociateProjectGroup } from '../typings/ApiClient';
import { IProjectBatchModel, ProcessProjectGroup } from '../models/ProjectBatch';

type Props = {
    saveBatch: () => void;
    updateProjectBatch: (projectBatchModel: IProjectBatchModel) => void;
    projectBatchModel: IProjectBatchModel
};
class AddBatchComponent extends React.Component<Props, { selectedSearchText: string, nonSelectedSearchText: string }> {
    public constructor(props: Props) {
        super(props);
        this.state = { selectedSearchText: '', nonSelectedSearchText: '' };
    }
    private selectedProjectGroup = React.createRef<HTMLSelectElement>();
    private nonSelectedProjectGroup = React.createRef<HTMLSelectElement>();
    private selectProjectBatch(isAll: boolean) {
        if (!this.nonSelectedProjectGroup.current) {
            return;
        }
        let options = this.nonSelectedProjectGroup.current.options;
        let selectedOptions: string[] = [];
        if (this.props.projectBatchModel.selectedProjectBatch) {
            selectedOptions = [...this.props.projectBatchModel.selectedProjectBatch];
        }
        for (let index = 0; index < options.length; index++) {
            if (options[index].selected || isAll) {
                selectedOptions.push(options[index].value);
            }
        }
        this.props.updateProjectBatch({ selectedProjectBatch: selectedOptions });
    }

    private unSelectProjectBatch(isAll: boolean) {
        if (!this.selectedProjectGroup.current) {
            return;
        }
        let options = this.selectedProjectGroup.current.options;
        let selectedOptions: string[] = [];
        if (this.props.projectBatchModel.selectedProjectBatch) {
            selectedOptions = [...this.props.projectBatchModel.selectedProjectBatch];
        }
        for (let index = 0; index < options.length; index++) {
            if (options[index].selected || isAll) {
                if (selectedOptions) {
                    const existingIndex = selectedOptions.findIndex(u => u === options[index].value);
                    selectedOptions.splice(existingIndex, 1);
                }
            }
        }
        this.props.updateProjectBatch({ selectedProjectBatch: selectedOptions });
    }

    private selectedSearchTextChange(event: React.ChangeEvent<HTMLInputElement>) {
        this.setState({ selectedSearchText: event.target.value });
    }

    private nonSelectedSearchTextChange(event: React.ChangeEvent<HTMLInputElement>) {
        this.setState({ nonSelectedSearchText: event.target.value });
    }

    private onChange(processProjectGroup?: ProcessProjectGroup) {
        this.props.updateProjectBatch({ ...this.props.projectBatchModel, processProjectGroup:  {...this.props.projectBatchModel.processProjectGroup, ...processProjectGroup} });
    }

    public render() {
        return (
            <div className="col-md-12" role="dialog" >
                <div className="modal-dialog">
                    <div className="modal-content">
                        <form className="form-horizontal">
                            <div className="modal-header">
                                <div>
                                    <h1>Add Batch</h1>
                                </div>
                            </div>
                            <div className="modal-body" >
                                <div className="md-dialog-container">
                                    <div className="form-group">
                                        <label className="control-label col-sm-3">Batch Name:</label>
                                        <div className="col-md-2">
                                            <input type="text" className="form-control" onChange={(event: React.ChangeEvent<HTMLInputElement>) => this.onChange({ name: event.target.value })} placeholder="Name" />
                                        </div>
                                        <label className="control-label col-sm-3">Start Date:</label>
                                        <div className="col-md-4">
                                            <input type="date" className="form-control" onChange={(event: React.ChangeEvent<HTMLInputElement>) => this.onChange({ startDate: new Date(event.target.value) })} placeholder="dd-MM-yyyy" />
                                        </div>
                                    </div>
                                    <div className="row center">
                                        <div className="col-md-5">
                                            <input className="form-control" onChange={(event: React.ChangeEvent<HTMLInputElement>) => this.selectedSearchTextChange(event)} type="text" placeholder="Filter" name="associateCodeNotInGroup" />
                                            <select ref={this.nonSelectedProjectGroup} className="form-control" multiple={true} key="non-selected">
                                                {this.props.projectBatchModel.associateProjectGroup && this.props.projectBatchModel.associateProjectGroup
                                                    .filter(u => !this.state.selectedSearchText || u.name && u.name.toLowerCase().includes(this.state.selectedSearchText.toLowerCase()))
                                                    .map((associateProjectGroup: AssociateProjectGroup) => {
                                                        if (!this.props.projectBatchModel.selectedProjectBatch ||
                                                            this.props.projectBatchModel.selectedProjectBatch &&
                                                            this.props.projectBatchModel.selectedProjectBatch.findIndex(u => u === associateProjectGroup.id) === -1) {
                                                            return (
                                                                <option key={associateProjectGroup.id} value={associateProjectGroup.id}>{associateProjectGroup.code + '-' + associateProjectGroup.name}</option>
                                                            );
                                                        }
                                                        return;
                                                    })}
                                            </select>
                                        </div>
                                        <div className="col-md-2 btn-group-vertical buttons">
                                            <button type="button" onClick={() => this.selectProjectBatch(true)} className="btn btn-default" title="Move all">
                                                <i className="glyphicon glyphicon-arrow-right" />
                                                <i className="glyphicon glyphicon-arrow-right" />
                                            </button>
                                            <button type="button" onClick={() => this.selectProjectBatch(false)} className="btn btn-default" title="Move selected">
                                                <i className="glyphicon glyphicon-arrow-right" />
                                            </button>
                                            <button type="button" onClick={() => this.unSelectProjectBatch(false)} className="btn btn-default" title="Remove selected">
                                                <i className="glyphicon glyphicon-arrow-left" />
                                            </button>
                                            <button type="button" onClick={() => this.unSelectProjectBatch(true)} className="btn btn-default" title="Remove all">
                                                <i className="glyphicon glyphicon-arrow-left" />
                                                <i className="glyphicon glyphicon-arrow-left" />
                                            </button>
                                        </div>
                                        <div className="col-md-5">
                                            <input className="form-control" onChange={(event: React.ChangeEvent<HTMLInputElement>) => this.nonSelectedSearchTextChange(event)} type="text" placeholder="Filter" name="associateCodeNotInGroup" />
                                            <select ref={this.selectedProjectGroup} className="form-control" multiple={true} key="non-selected">
                                                {this.props.projectBatchModel.associateProjectGroup && this.props.projectBatchModel.associateProjectGroup
                                                    .filter(u => !this.state.nonSelectedSearchText || u.name && u.name.toLowerCase().includes(this.state.nonSelectedSearchText.toLowerCase()))
                                                    .filter(u => (this.props.projectBatchModel.selectedProjectBatch && this.props.projectBatchModel.selectedProjectBatch
                                                        .some(x => x === u.id))).map((associateProjectGroup: AssociateProjectGroup) => {
                                                            return (
                                                                <option key={associateProjectGroup.id} value={associateProjectGroup.id}>{associateProjectGroup.code + '-' + associateProjectGroup.name}</option>
                                                            );
                                                        })}
                                            </select>
                                        </div>
                                    </div>
                                    <div className="row" />
                                </div>
                            </div>
                            <div className="form-group">
                                <div className="col-sm-2">
                                    <button type="button" className="btn btn-secondary btn pull-right" onClick={() => this.props.updateProjectBatch({ showAddBatch: false })}>Cancel</button>
                                </div>
                                <div className="col-sm-2">
                                    <button type="button" onClick={() => this.props.saveBatch()} className="btn btn-primary btn pull-right">Add</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        );
    }
}
export default AddBatchComponent;