import * as React from 'react';
import LoginComponent from '../components/LoginComponent';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import { onLogin, onAssociateIdChange } from '../actions/LoginActions';
import SessionManagement from '../utils/SessionManagement';
import { Redirect } from 'react-router';
import { ILoginContainerProps, ILoginState } from '../models/Login';

class LoginContainer extends React.Component<ILoginContainerProps, ILoginState> {
    public constructor(props: ILoginContainerProps) {
        super(props);
    }

    private handleOnChange = (event: React.ChangeEvent<HTMLInputElement>): void => {
        if (Number(event.target.value)) {
            this.props.onAssociateIdChange(parseInt(event.target.value, 0));
        }
    };

    private handleOnLogin = (): void => {
        this.props.onLogin(this.props.associateId);
        this.props.onAuthenticated();
    };

    public render() {
        if (this.props.isAuthenticated && this.props.isAdmin) {
            return (<Redirect to="/" />);
        }
        
        if (this.props.isAuthenticated) {
            return (<Redirect to="/kt-detail" />);
        }
        return (<LoginComponent associateId={this.props.associateId} onChange={(event: React.ChangeEvent<HTMLInputElement>) => this.handleOnChange(event)} onLogin={() => this.handleOnLogin()} />);
    }
}

const mapStateToProps = ({ login: login }: any) => {
    return {
        associateId: login.associateId,
        isAuthenticated: SessionManagement.GetToken() ? true : false,
        isAdmin: login.isAdmin
    };
};

const mapDispatchToProps = (dispatch: any) =>
    bindActionCreators(
        {
            onLogin,
            onAssociateIdChange
        },
        dispatch
    );

export default connect(
    mapStateToProps,
    mapDispatchToProps
)(LoginContainer);
