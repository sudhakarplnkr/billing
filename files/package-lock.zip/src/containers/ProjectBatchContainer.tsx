import * as React from 'react';
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import { loadProjects, loadBatches, loadProjectGroupPlan, showModal, loadAddPlan, loadAddBatch, updateProjectBatch, loadAssociateStatus, createBatch, saveBatch, deleteBatch } from '../actions/ProjectBatchActions';
import ProjectBatchComponent from '../components/ProjectBatchComponent';
import { IProjectState, IProjectProps, IProjectBatchModel } from '../models/ProjectBatch';
import { ProcessCreateProjectGroup, ProcessUpdateProjectGroup, Associate } from '../typings/ApiClient';
import { toastr } from 'react-redux-toastr';

class ProjectBatchContainer extends React.Component<IProjectProps, IProjectState> {

    public componentWillMount() {
        this.props.loadProjects();
    }

    private updateProjectBatch(projectBatchModel: IProjectBatchModel) {
        const model: IProjectBatchModel = { ...this.props.projectBatchModel, ...projectBatchModel };
        this.props.updateProjectBatch(model);
    }

    private onProjectSelect(projectId: string) {
        const project = this.props.projectBatchModel.project && this.props.projectBatchModel.project.filter(u => u.id === projectId).pop();
        const model = { ...this.props.projectBatchModel, selectedProject: project };
        this.props.updateProjectBatch(model);
        this.props.loadBatches(projectId);
    }

    private onBatchSelect(batchId: string) {
        const batch = this.props.projectBatchModel.batch && this.props.projectBatchModel.batch.filter(u => u.id === batchId).pop();
        const model = { ...this.props.projectBatchModel, selectedBatch: batch };
        this.props.updateProjectBatch(model);
        this.props.loadProjectGroupPlan(batchId);
    }

    private saveBatch() {
        if (!this.props.projectBatchModel.processProjectGroup || this.props.projectBatchModel.processProjectGroup && !this.props.projectBatchModel.processProjectGroup.name) {
            toastr.error('Batch', 'please enter name of the batch.');
            return;
        }
        if (!this.props.projectBatchModel.processProjectGroup || this.props.projectBatchModel.processProjectGroup && !this.props.projectBatchModel.processProjectGroup.startDate) {
            toastr.error('Batch', 'please select start date of the batch.');
            return;
        }
        if (!this.props.projectBatchModel.selectedProjectBatch) {
            toastr.error('Batch', 'please select atleast one associate to save or create batch.');
            return;
        }
        if (this.props.projectBatchModel.selectedBatch && this.props.projectBatchModel.selectedBatch.id) {
            const model = { ...this.props.projectBatchModel.processProjectGroup, projectGroupId: this.props.projectBatchModel.selectedBatch.id } as ProcessUpdateProjectGroup;
            this.props.saveBatch(model.projectGroupId, model);
        } else if (this.props.projectBatchModel.selectedProject && this.props.projectBatchModel.selectedProjectBatch) {
            const selectedAssociate = [...this.props.projectBatchModel.selectedProjectBatch];
            const associates: Associate[] = [];
            selectedAssociate.forEach((associate: string) => {
                const associateProjectGroup = this.props.projectBatchModel.associateProjectGroup && this.props.projectBatchModel.associateProjectGroup.filter(u => u.id === associate).pop();
                if (associateProjectGroup) {
                    associates.push({ id: associate, roleId: associateProjectGroup.roleId } as Associate);
                }
            });
            this.updateProjectBatch({ showAddBatch: false, selectedProject: undefined, batch: [], selectedProjectBatch: [], projectGroupPlan: [] });
            this.props.createBatch({ ...this.props.projectBatchModel.processProjectGroup, projectId: this.props.projectBatchModel.selectedProject.id, addAssociates: associates } as ProcessCreateProjectGroup);
        }
    }

    private loadAddBatch(addBatch: boolean) {
        if (this.props.projectBatchModel.selectedProject && this.props.projectBatchModel.selectedBatch) {
            this.props.loadAddBatch(addBatch, this.props.projectBatchModel.selectedProject.id, this.props.projectBatchModel.selectedBatch.id);
        } else if (this.props.projectBatchModel.selectedProject) {
            this.props.loadAddBatch(addBatch, this.props.projectBatchModel.selectedProject.id, '');
        }
    }
    private deleteBatch() {
        if (this.props.projectBatchModel.selectedBatch) {            
            this.updateProjectBatch({ selectedProject: undefined, batch: [], selectedProjectBatch: [], projectGroupPlan: [], showDialog: false });
            this.props.deleteBatch(this.props.projectBatchModel.selectedBatch.id);
        }
    }
    public render() {
        return (
            <ProjectBatchComponent
                deleteBatch={() => this.deleteBatch()}
                loadAddBatch={(addBatch: boolean) => this.loadAddBatch(addBatch)}
                saveBatch={() => this.saveBatch()}
                updateProjectBatch={(projectBatchModel: IProjectBatchModel) => this.updateProjectBatch(projectBatchModel)}
                loadBatches={(projectId: string) => this.onProjectSelect(projectId)}
                loadProjectGroupPlan={(batchId: string) => this.onBatchSelect(batchId)}
                projectBatchModel={this.props.projectBatchModel}
                showModal={(show: Boolean) => this.props.showModal(show)}
                loadAddPlan={(addPlan: Boolean, planTitle: string) => this.props.loadAddPlan(addPlan, planTitle)}
                loadAssociateStatus={(groupPlan: Boolean, groupPlanId: string) => this.props.loadAssociateStatus(groupPlan, groupPlanId)}
            />
        );
    }
}
const mapStateToProps = (state: any) => {
    return {
        projectBatchModel: state.projectBatch.projectBatchModel
    };
};

const mapDispatchToProps = (dispatch: any) =>
    bindActionCreators(
        {
            loadProjects,
            loadBatches,
            loadProjectGroupPlan,
            showModal,
            loadAddPlan,
            loadAddBatch,
            loadAssociateStatus,
            updateProjectBatch,
            createBatch,
            saveBatch,
            deleteBatch
        },
        dispatch
    );

export default connect(
    mapStateToProps,
    mapDispatchToProps
)(ProjectBatchContainer);