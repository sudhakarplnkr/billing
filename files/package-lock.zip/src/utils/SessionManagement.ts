class SessionManagement {

    private readonly tokenKey = 'AssociateId';

    public GetToken(): string {
        const token = sessionStorage.getItem(this.tokenKey);
        return this.nullChecker(token);
    }

    public SetToken(token: string): void {
        sessionStorage.setItem(this.tokenKey, token);
    }

    public RemoveToken(): void {
        sessionStorage.removeItem(this.tokenKey);
    }

    private nullChecker(token: string | null): string {
        return token ? token : '';
    }
}

export default new SessionManagement();