import * as React from 'react';

const Header = () => {  
  return (<img src={'../../logo.png'} title="logo" />);
};

export default Header;